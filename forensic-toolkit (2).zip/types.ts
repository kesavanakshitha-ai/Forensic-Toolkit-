
export interface Environment {
  temperatureC: number;
  pressureHpa: number;
  humidity: number; // 0 to 1
  altitudeM: number;
  windSpeed: number; // m/s
  windAngleDeg: number; // degrees
}

export interface Firearm {
  id: string;
  name: string;
  caliber: string;
  muzzleVelocity: number; // m/s
  bulletMass: number; // grams
  ballisticCoefficient: number;
  barrelLength: number; // meters
}

export interface BallisticsInputs {
  firearmId: string;
  targetDistance: number;
  sightHeight: number; // in meters
  environment: Environment;
}

export interface TrajectoryPoint {
  distance: number;
  drop: number;
  windDrift: number;
  velocity: number;
  energy: number;
}

export interface BallisticsResults {
  trajectory: TrajectoryPoint[];
}

export interface FingerprintAnalysisResult {
  matchConfidence: number;
  nistVerified: boolean;
  minutiaePoints?: number; // Example additional detail
}

export interface BlockchainEvidenceInput {
  caseId: string;
  evidenceHash: string;
  evidenceDescription: string;
}

export interface BlockchainStoreResult {
  transactionHash: string;
  timestamp: string;
  blockNumber?: number; // Example additional detail
}

export interface BloodstainInputs {
  stainWidth: number;
  stainLength: number;
}

export interface BloodstainResult {
  impactAngle: number;
}

export interface Substance {
  id: string;
  name: string;
  chemicalName: string;
  formula: string;
  category: 'Narcotic' | 'Stimulant' | 'Depressant' | 'Hallucinogen' | 'Toxin';
  effects: string;
  lethalDose?: string;
  detectionMethods: string;
  legalStatus: string;
}

export interface SubstanceAnalysisResult {
  identifiedSubstance: Substance;
  matchConfidence: number; // 0 to 100
}

export enum Tool {
  Ballistics = 'Ballistics Calculator',
  Fingerprint = 'Fingerprint Analyzer',
  Blockchain = 'Blockchain Evidence Manager',
  Bloodstain = 'Bloodstain Pattern Analyzer',
  Substance = 'Substance Identifier',
}

export interface GeminiExplanationRequest {
  toolName: Tool;
  inputs: any;
  results: any;
}