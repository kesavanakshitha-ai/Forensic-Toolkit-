
import React from 'react';
import { Routes, Route, Outlet, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import DashboardPage from './pages/DashboardPage';
import BallisticsCalculatorPage from './pages/BallisticsCalculatorPage';
import FingerprintAnalyzerPage from './pages/FingerprintAnalyzerPage';
import BlockchainEvidencePage from './pages/BlockchainEvidencePage';
import BloodstainAnalyzerPage from './pages/BloodstainAnalyzerPage';
import SubstanceIdentifierPage from './pages/SubstanceIdentifierPage';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ProtectedRoute from './components/ProtectedRoute';
import { useAuth } from './context/AuthContext';

const AppLayout: React.FC = () => (
  <div className="flex flex-col min-h-screen bg-brand-dark text-brand-light">
    <Header />
    <main className="flex-grow container mx-auto px-4 py-8">
      <Outlet />
    </main>
    <Footer />
  </div>
);

const App: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      
      <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/ballistics" element={<BallisticsCalculatorPage />} />
        <Route path="/fingerprint" element={<FingerprintAnalyzerPage />} />
        <Route path="/blockchain" element={<BlockchainEvidencePage />} />
        <Route path="/bloodstain" element={<BloodstainAnalyzerPage />} />
        <Route path="/substance" element={<SubstanceIdentifierPage />} />
      </Route>

      <Route path="*" element={<NavigateToDefault />} />
    </Routes>
  );
};

const NavigateToDefault: React.FC = () => {
  const { user } = useAuth();
  return <Navigate to={user ? "/dashboard" : "/"} replace />;
};

export default App;