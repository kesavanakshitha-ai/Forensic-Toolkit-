import { BallisticsInputs, BallisticsResults, FingerprintAnalysisResult, BlockchainEvidenceInput, BlockchainStoreResult, BloodstainInputs, BloodstainResult, Firearm, Environment, TrajectoryPoint, Substance, SubstanceAnalysisResult } from '../types';

export const firearms: Firearm[] = [
    { "id": "atchissonaa12", "name": "Atchisson AA-12", "caliber": "12 Gauge", "muzzleVelocity": 400, "bulletMass": 28.4, "ballisticCoefficient": 0.018, "barrelLength": 0.457 },
    { "id": "arisakarifle", "name": "Arisaka rifle", "caliber": "6.5x50mmSR", "muzzleVelocity": 760, "bulletMass": 9, "ballisticCoefficient": 0.3, "barrelLength": 0.797 },
    { "id": "ak47", "name": "AK-47", "caliber": "7.62x39mm", "muzzleVelocity": 715, "bulletMass": 8, "ballisticCoefficient": 0.29, "barrelLength": 0.415 },
    { "id": "ak74", "name": "AK-74", "caliber": "5.45x39mm", "muzzleVelocity": 900, "bulletMass": 3.4, "ballisticCoefficient": 0.31, "barrelLength": 0.415 },
    { "id": "ak74m", "name": "AK-74M", "caliber": "5.45x39mm", "muzzleVelocity": 900, "bulletMass": 3.4, "ballisticCoefficient": 0.31, "barrelLength": 0.415 },
    { "id": "akm", "name": "AKM", "caliber": "7.62x39mm", "muzzleVelocity": 715, "bulletMass": 8, "ballisticCoefficient": 0.29, "barrelLength": 0.415 },
    { "id": "ak12", "name": "AK-12", "caliber": "5.45x39mm", "muzzleVelocity": 900, "bulletMass": 3.4, "ballisticCoefficient": 0.31, "barrelLength": 0.415 },
    { "id": "ak15", "name": "AK-15", "caliber": "7.62x39mm", "muzzleVelocity": 715, "bulletMass": 8, "ballisticCoefficient": 0.29, "barrelLength": 0.415 },
    { "id": "ak19", "name": "AK-19", "caliber": "5.56x45mm NATO", "muzzleVelocity": 900, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.415 },
    { "id": "ak101", "name": "AK-101", "caliber": "5.56x45mm NATO", "muzzleVelocity": 900, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.415 },
    { "id": "ak102", "name": "AK-102", "caliber": "5.56x45mm NATO", "muzzleVelocity": 850, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.314 },
    { "id": "ak103", "name": "AK-103", "caliber": "7.62x39mm", "muzzleVelocity": 715, "bulletMass": 8, "ballisticCoefficient": 0.29, "barrelLength": 0.415 },
    { "id": "ak104", "name": "AK-104", "caliber": "7.62x39mm", "muzzleVelocity": 670, "bulletMass": 8, "ballisticCoefficient": 0.29, "barrelLength": 0.314 },
    { "id": "ak105", "name": "AK-105", "caliber": "5.45x39mm", "muzzleVelocity": 840, "bulletMass": 3.4, "ballisticCoefficient": 0.31, "barrelLength": 0.314 },
    { "id": "ak200", "name": "AK-200", "caliber": "5.45x39mm", "muzzleVelocity": 900, "bulletMass": 3.4, "ballisticCoefficient": 0.31, "barrelLength": 0.415 },
    { "id": "ak201", "name": "AK-201", "caliber": "5.56x45mm NATO", "muzzleVelocity": 900, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.415 },
    { "id": "ak203", "name": "AK-203", "caliber": "7.62x39mm", "muzzleVelocity": 715, "bulletMass": 8, "ballisticCoefficient": 0.29, "barrelLength": 0.415 },
    { "id": "ak204", "name": "AK-204", "caliber": "7.62x39mm", "muzzleVelocity": 670, "bulletMass": 8, "ballisticCoefficient": 0.29, "barrelLength": 0.314 },
    { "id": "ak205", "name": "AK-205", "caliber": "5.45x39mm", "muzzleVelocity": 840, "bulletMass": 3.4, "ballisticCoefficient": 0.31, "barrelLength": 0.314 },
    { "id": "ak308", "name": "AK-308", "caliber": "7.62x51mm NATO", "muzzleVelocity": 800, "bulletMass": 9.5, "ballisticCoefficient": 0.4, "barrelLength": 0.415 },
    { "id": "aks74u", "name": "AKS-74U", "caliber": "5.45x39mm", "muzzleVelocity": 735, "bulletMass": 3.4, "ballisticCoefficient": 0.31, "barrelLength": 0.206 },
    { "id": "ak55", "name": "AK-55", "caliber": "5.56x45mm NATO", "muzzleVelocity": 900, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.415 },
    { "id": "akv521", "name": "AKV-521", "caliber": "7.62x39mm", "muzzleVelocity": 715, "bulletMass": 8, "ballisticCoefficient": 0.29, "barrelLength": 0.415 },
    { "id": "ak56", "name": "AK-56", "caliber": "7.62x39mm", "muzzleVelocity": 715, "bulletMass": 8, "ballisticCoefficient": 0.29, "barrelLength": 0.415 },
    { "id": "american180", "name": "American-180", "caliber": ".22 LR", "muzzleVelocity": 390, "bulletMass": 2.6, "ballisticCoefficient": 0.125, "barrelLength": 0.406 },
    { "id": "angstadtarmsmdp9", "name": "Angstadt Arms MDP-9", "caliber": "9x19mm", "muzzleVelocity": 350, "bulletMass": 8, "ballisticCoefficient": 0.15, "barrelLength": 0.14 },
    { "id": "ar5", "name": "AR-5", "caliber": ".22 Hornet", "muzzleVelocity": 760, "bulletMass": 3.24, "ballisticCoefficient": 0.22, "barrelLength": 0.56 },
    { "id": "ar50", "name": "AR-50", "caliber": ".50 BMG", "muzzleVelocity": 853, "bulletMass": 42, "ballisticCoefficient": 0.71, "barrelLength": 0.762 },
    { "id": "ar57", "name": "AR-57", "caliber": "5.7x28mm", "muzzleVelocity": 720, "bulletMass": 2.6, "ballisticCoefficient": 0.175, "barrelLength": 0.406 },
    { "id": "ar7", "name": "AR-7", "caliber": ".22 LR", "muzzleVelocity": 380, "bulletMass": 2.6, "ballisticCoefficient": 0.125, "barrelLength": 0.406 },
    { "id": "ar10", "name": "AR-10", "caliber": "7.62x51mm NATO", "muzzleVelocity": 840, "bulletMass": 9.5, "ballisticCoefficient": 0.4, "barrelLength": 0.508 },
    { "id": "ar12", "name": "AR-12", "caliber": "12 Gauge", "muzzleVelocity": 400, "bulletMass": 28.4, "ballisticCoefficient": 0.018, "barrelLength": 0.457 },
    { "id": "ar13", "name": "AR-13", "caliber": "Unknown", "muzzleVelocity": 0, "bulletMass": 0, "ballisticCoefficient": 0, "barrelLength": 0 },
    { "id": "ar15", "name": "AR15", "caliber": "5.56x45mm NATO", "muzzleVelocity": 900, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.41 },
    { "id": "asval", "name": "AS VAL", "caliber": "9x39mm", "muzzleVelocity": 290, "bulletMass": 16.2, "ballisticCoefficient": 0.34, "barrelLength": 0.2 },
    { "id": "ar16", "name": "AR-16", "caliber": "7.62x51mm NATO", "muzzleVelocity": 838, "bulletMass": 9.5, "ballisticCoefficient": 0.4, "barrelLength": 0.508 },
    { "id": "ar18", "name": "AR-18", "caliber": "5.56x45mm NATO", "muzzleVelocity": 990, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.419 },
    { "id": "ar100", "name": "AR-100", "caliber": "5.56x45mm NATO", "muzzleVelocity": 940, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.465 },
    { "id": "an94", "name": "AN-94", "caliber": "5.45x39mm", "muzzleVelocity": 900, "bulletMass": 3.4, "ballisticCoefficient": 0.31, "barrelLength": 0.405 },
    { "id": "auga1", "name": "AUG A1", "caliber": "5.56x45mm NATO", "muzzleVelocity": 940, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.508 },
    { "id": "auga2", "name": "AUG A2", "caliber": "5.56x45mm NATO", "muzzleVelocity": 940, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.508 },
    { "id": "auga3", "name": "AUG A3", "caliber": "5.56x45mm NATO", "muzzleVelocity": 940, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.508 },
    { "id": "auga3para", "name": "AUG A3 PARA", "caliber": "9x19mm", "muzzleVelocity": 400, "bulletMass": 8, "ballisticCoefficient": 0.15, "barrelLength": 0.42 },
    { "id": "a91p", "name": "A-91-P", "caliber": "5.56x45mm NATO", "muzzleVelocity": 900, "bulletMass": 4, "ballisticCoefficient": 0.3, "barrelLength": 0.415 },
    { "id": "a91", "name": "A-91", "caliber": "7.62x39mm", "muzzleVelocity": 715, "bulletMass": 8, "ballisticCoefficient": 0.29, "barrelLength": 0.415 },
];

export const substances: Substance[] = [
    {
        id: 'cocaine',
        name: 'Cocaine',
        chemicalName: 'Benzoylmethylecgonine',
        formula: 'C17H21NO4',
        category: 'Stimulant',
        effects: 'Euphoria, increased energy, alertness, decreased appetite.',
        lethalDose: '1.2g (oral), varies significantly.',
        detectionMethods: 'Gas chromatography-mass spectrometry (GC-MS), immunoassays.',
        legalStatus: 'Schedule II (US), Class A (UK).',
    },
    {
        id: 'heroin',
        name: 'Heroin',
        chemicalName: 'Diacetylmorphine',
        formula: 'C21H23NO5',
        category: 'Narcotic',
        effects: 'Euphoria, pain relief, sedation, respiratory depression.',
        lethalDose: '30-75mg for non-tolerant users.',
        detectionMethods: 'GC-MS, liquid chromatography-mass spectrometry (LC-MS).',
        legalStatus: 'Schedule I (US), Class A (UK).',
    },
    {
        id: 'thc',
        name: 'Tetrahydrocannabinol (THC)',
        chemicalName: 'Δ⁹-Tetrahydrocannabinol',
        formula: 'C21H30O2',
        category: 'Hallucinogen',
        effects: 'Altered perception, euphoria, relaxation, increased appetite.',
        lethalDose: 'Very high, non-fatal in humans from overdose alone.',
        detectionMethods: 'Immunoassays (urine), GC-MS (blood/saliva).',
        legalStatus: 'Varies by jurisdiction (Schedule I federally in US).',
    },
    {
        id: 'ricin',
        name: 'Ricin',
        chemicalName: 'Ricin Toxin',
        formula: 'Complex Protein',
        category: 'Toxin',
        effects: 'Inhibits protein synthesis, causing cell death. Nausea, internal bleeding, organ failure.',
        lethalDose: 'Approx. 500 micrograms (injected/inhaled).',
        detectionMethods: 'ELISA, polymerase chain reaction (PCR).',
        legalStatus: 'Regulated under chemical weapons conventions.',
    }
];

const airDensity = (environment: Environment): number => {
    const { temperatureC, pressureHpa } = environment;
    const T = temperatureC + 273.15; // Kelvin
    const p = pressureHpa * 100; // Pascals
    const R = 287.05; // Specific gas constant for dry air
    return p / (R * T);
};

export const calculateBallistics = async (inputs: BallisticsInputs): Promise<BallisticsResults> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
        const { firearmId, targetDistance, sightHeight, environment } = inputs;
        const firearm = firearms.find(f => f.id === firearmId);

        if (!firearm) {
            return reject(new Error("Firearm not found"));
        }
        if (targetDistance <= 0 || firearm.muzzleVelocity <= 0 || firearm.ballisticCoefficient <=0) {
            return resolve({ trajectory: [] });
        }

        const g = 9.81;
        const rho = airDensity(environment);
        const massKg = firearm.bulletMass / 1000;
        const bc = firearm.ballisticCoefficient;
        const crossWind = environment.windSpeed * Math.sin((environment.windAngleDeg * Math.PI) / 180);

        // --- Step 1: Simulate trajectory from a horizontal bore ---
        const bore_path: {x: number, y: number, vx: number, vy: number, t: number}[] = [];
        let x = 0, y = 0, vx = firearm.muzzleVelocity, vy = 0, t = 0;
        const dt = 0.001; // Simulation time step for accuracy

        bore_path.push({x,y,vx,vy,t});

        while (x < targetDistance) {
            const v_sq = vx*vx + vy*vy;
            const v_current = Math.sqrt(v_sq);
            if (v_current === 0) break;

            // Simplified drag model from user-provided code
            const dragForce = 0.5 * rho * v_sq * (0.0001 / bc);

            const ax = -dragForce * (vx / v_current) / massKg;
            const ay = -g - (dragForce * (vy / v_current) / massKg);

            vx += ax * dt;
            vy += ay * dt;
            x += vx * dt;
            y += vy * dt;
            t += dt;

            bore_path.push({x,y,vx,vy,t});
        }
        
        const y_bore_at_target = bore_path[bore_path.length - 1].y;

        // --- Step 2 & 3: Define LOS and calculate drop relative to it ---
        const trajectory: TrajectoryPoint[] = [];
        const num_points = 50; // Generate 50 points for a smooth chart

        for (let j = 0; j <= num_points; j++) {
            const dist = (targetDistance / num_points) * j;

            // Find the closest point in our high-resolution simulation
            let path_point = bore_path[0];
            for(const p of bore_path) {
                if(p.x >= dist) {
                    path_point = p;
                    break;
                }
                path_point = p;
            }
            
            // Line of sight is a straight line from (0, sightHeight) to (targetDistance, y_bore_at_target)
            // This ensures the drop is 0 at the target distance (i.e., it's "zeroed")
            const y_los = sightHeight + (y_bore_at_target - sightHeight) * (path_point.x / targetDistance);
            const drop = path_point.y - y_los;
            
            const windDrift = crossWind * path_point.t;
            const velocity = Math.sqrt(path_point.vx**2 + path_point.vy**2);
            const energy = 0.5 * massKg * velocity**2;

            trajectory.push({
                distance: dist,
                drop: drop,
                windDrift: windDrift,
                velocity: velocity,
                energy: energy
            });
        }

        resolve({ trajectory });
    }, 500);
  });
};


export const analyzeFingerprint = async (): Promise<FingerprintAnalysisResult> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        matchConfidence: parseFloat((Math.random() * (99.9 - 70) + 70).toFixed(2)), // Random confidence between 70% and 99.9%
        nistVerified: Math.random() > 0.3, // 70% chance of being NIST verified
        minutiaePoints: Math.floor(Math.random() * (50 - 10 + 1)) + 10 // Random number of minutiae points
      });
    }, 800);
  });
};

export const storeEvidenceOnBlockchain = async (input: BlockchainEvidenceInput): Promise<BlockchainStoreResult> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        transactionHash: `0x${[...Array(64)].map(() => Math.floor(Math.random() * 16).toString(16)).join('')}`,
        timestamp: new Date().toISOString(),
        blockNumber: Math.floor(Math.random() * 1000000) + 1000000
      });
    }, 1200);
  });
};

export const calculateBloodstainAngle = async (inputs: BloodstainInputs): Promise<BloodstainResult> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const { stainWidth, stainLength } = inputs;
      if (stainLength === 0 || stainWidth > stainLength) {
        resolve({ impactAngle: 0 });
        return;
      }
      const angleRad = Math.asin(stainWidth / stainLength);
      const impactAngle = (angleRad * 180) / Math.PI;
      resolve({ impactAngle: parseFloat(impactAngle.toFixed(2)) });
    }, 300);
  });
};

export const identifySubstance = async (): Promise<SubstanceAnalysisResult> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      const randomSubstance = substances[Math.floor(Math.random() * substances.length)];
      resolve({
        identifiedSubstance: randomSubstance,
        matchConfidence: parseFloat((Math.random() * (99.8 - 85.0) + 85.0).toFixed(2)),
      });
    }, 1500); // Simulate longer analysis time
  });
};