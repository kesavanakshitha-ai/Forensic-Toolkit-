
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GeminiExplanationRequest, Tool } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY for Gemini is not set. Please ensure the process.env.API_KEY environment variable is configured.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "MISSING_API_KEY" }); // Fallback to prevent crash if not set, but will fail API calls
const model = 'gemini-2.5-flash';

const getSystemInstruction = (toolName: Tool): string => {
  switch (toolName) {
    case Tool.Ballistics:
      return "You are a forensic ballistics expert. Provide a concise, professional explanation of the significance of the given ballistics data. Focus on how environmental factors like wind and temperature, along with firearm choice, affect the bullet's trajectory, drop, and energy at the target distance. Explain the implications for crime scene reconstruction.";
    case Tool.Fingerprint:
      return "You are a forensic fingerprint analysis expert. Explain the provided fingerprint analysis results in a clear, concise manner suitable for a non-expert, highlighting confidence levels and verification significance.";
    case Tool.Blockchain:
      return "You are a digital forensics expert specializing in blockchain. Explain the significance of the blockchain transaction details for evidence integrity and chain of custody. Assume the user has basic knowledge of blockchain.";
    case Tool.Bloodstain:
      return "You are a forensic expert in bloodstain pattern analysis. Concisely explain the meaning of the calculated impact angle and its potential implications in reconstructing events at a crime scene.";
    case Tool.Substance:
      return "You are a forensic toxicologist and chemist. Explain the provided substance analysis results for a law enforcement context. Detail the substance's category, common effects, potential dangers, legal status, and the significance of the findings in a forensic investigation. Be clear, professional, and concise.";
    default:
      return "You are a helpful AI assistant specializing in forensic science. Provide a clear and concise explanation of the provided data.";
  }
};

export const getGeminiExplanation = async (request: GeminiExplanationRequest): Promise<string> => {
  if (!API_KEY) {
    return "Error: Gemini API Key is not configured. AI insights are unavailable.";
  }
  
  const { toolName, inputs, results } = request;

  let promptContent = `Tool: ${toolName}\n`;
  promptContent += `Inputs: ${JSON.stringify(inputs, null, 2)}\n\n`;

  if (toolName === Tool.Ballistics && results.trajectory && results.trajectory.length > 0) {
    const finalPoint = results.trajectory[results.trajectory.length - 1];
    promptContent += `Results at Target Distance (${finalPoint.distance.toFixed(0)}m):\n`;
    promptContent += ` - Bullet Drop: ${finalPoint.drop.toFixed(2)} m\n`;
    promptContent += ` - Wind Drift: ${finalPoint.windDrift.toFixed(2)} m\n`;
    promptContent += ` - Final Velocity: ${finalPoint.velocity.toFixed(0)} m/s\n`;
    promptContent += ` - Final Energy: ${finalPoint.energy.toFixed(0)} J\n\n`;
  } else {
    promptContent += `Results: ${JSON.stringify(results, null, 2)}\n\n`;
  }
  
  promptContent += `Based on the above information, provide a forensic explanation.`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: model,
      contents: promptContent,
      config: {
        systemInstruction: getSystemInstruction(toolName),
        temperature: 0.5,
        topK: 32,
        topP: 0.9,
      }
    });
    
    const text = response.text;
    if (text) {
      return text;
    }
    return "No explanation generated, or an unexpected response format was received.";

  } catch (error: any) {
    console.error("Error calling Gemini API:", error);
    let errorMessage = "An error occurred while fetching AI insights.";
    if (error.message) {
      errorMessage += ` Details: ${error.message}`;
    }
    if (error.response && error.response.data && error.response.data.error) {
        errorMessage += ` Server Message: ${error.response.data.error.message}`;
    } else if (error.message && error.message.includes('API_KEY_INVALID')) {
        errorMessage = "Error: The Gemini API Key is invalid. Please check your configuration.";
    } else if (error.message && error.message.includes('quota')) {
        errorMessage = "Error: API quota exceeded. Please try again later or check your Gemini API quota.";
    }
    return errorMessage;
  }
};