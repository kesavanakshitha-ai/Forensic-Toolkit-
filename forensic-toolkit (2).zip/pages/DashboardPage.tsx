
import React from 'react';
import ToolCard from '../components/ToolCard';
import BallisticsIcon from '../components/icons/BallisticsIcon';
import FingerprintIcon from '../components/icons/FingerprintIcon';
import BlockchainIcon from '../components/icons/BlockchainIcon';
import BloodstainIcon from '../components/icons/BloodstainIcon';
import SubstanceIcon from '../components/icons/SubstanceIcon';
import { Tool } from '../types';

const DashboardPage: React.FC = () => {
  const tools = [
    {
      title: Tool.Ballistics,
      description: 'Calculate projectile trajectory, range, and impact parameters.',
      linkTo: '/ballistics',
      icon: <BallisticsIcon className="h-8 w-8" />
    },
    {
      title: Tool.Fingerprint,
      description: 'Simulate fingerprint matching and NIST verification status.',
      linkTo: '/fingerprint',
      icon: <FingerprintIcon className="h-8 w-8" />
    },
    {
      title: Tool.Blockchain,
      description: 'Log and verify evidence hashes on a simulated blockchain.',
      linkTo: '/blockchain',
      icon: <BlockchainIcon className="h-8 w-8" />
    },
    {
      title: Tool.Bloodstain,
      description: 'Analyze bloodstain patterns to determine impact angles.',
      linkTo: '/bloodstain',
      icon: <BloodstainIcon className="h-8 w-8" />
    },
    {
      title: Tool.Substance,
      description: 'Identify unknown substances using a simulated database.',
      linkTo: '/substance',
      icon: <SubstanceIcon className="h-8 w-8" />
    },
  ];

  return (
    <div className="animate-fadeIn">
      <h1 className="text-4xl font-bold mb-2 text-sky-400">Forensic Toolkit Dashboard</h1>
      <p className="text-lg text-slate-300 mb-10">Select a tool below to begin your analysis.</p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
        {tools.map((tool) => (
          <ToolCard
            key={tool.title}
            title={tool.title}
            description={tool.description}
            linkTo={tool.linkTo}
            icon={tool.icon}
          />
        ))}
      </div>
    </div>
  );
};

export default DashboardPage;

// Minimal CSS for fadeIn animation (can be added to tailwind.config.js or here for simplicity if allowed)
// For this exercise, assuming direct style or it's already part of a global setup
// <style>
// @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
// .animate-fadeIn { animation: fadeIn 0.5s ease-out forwards; }
// </style>
// Since direct style tags are not allowed and separate CSS files are restricted,
// this animation is best handled by adding it to the Tailwind config if persistence is needed,
// or by using a library like framer-motion. For now, the class name is indicative.
// Tailwind JIT usually needs to see class names to generate them.
// A simple way is to just ensure content appears without complex animation if setup is tricky.
// The current Tailwind setup via CDN script tag might not support custom animation keyframes easily.
// We will rely on Tailwind's default transition utilities for hover effects on cards.