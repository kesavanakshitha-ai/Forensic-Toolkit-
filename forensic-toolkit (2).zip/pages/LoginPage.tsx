
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { BeakerIcon } from '@heroicons/react/24/solid';

const LoginPage: React.FC = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const { login } = useAuth();
    const [error, setError] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!email || !password) {
            setError('Please enter both email and password.');
            return;
        }
        setError('');
        // Password validation is skipped for this simulation
        login(email);
    };

    return (
        <div className="min-h-screen bg-brand-dark flex items-center justify-center p-4">
            <div className="max-w-md w-full bg-slate-800 p-8 rounded-xl shadow-2xl border border-slate-700">
                <div className="text-center mb-8">
                    <BeakerIcon className="h-12 w-12 text-brand-accent mx-auto mb-2" />
                    <h1 className="text-3xl font-bold text-sky-400">Login</h1>
                    <p className="text-slate-400">Access your Forensic Toolkit dashboard.</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-slate-300 mb-1">Email Address</label>
                        <input
                            type="email"
                            id="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            required
                            className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md focus:ring-brand-accent focus:border-brand-accent text-slate-100 placeholder-slate-400"
                            placeholder="you@agency.gov"
                        />
                    </div>
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-slate-300 mb-1">Password</label>
                        <input
                            type="password"
                            id="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            required
                            className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md focus:ring-brand-accent focus:border-brand-accent text-slate-100"
                            placeholder="••••••••"
                        />
                    </div>
                    {error && <p className="text-red-400 text-sm">{error}</p>}
                    <button type="submit" className="w-full px-6 py-3 bg-brand-accent text-white font-semibold rounded-md hover:bg-sky-500 transition-colors">
                        Login
                    </button>
                </form>
                <p className="text-center text-sm text-slate-400 mt-6">
                    Don't have an account?{' '}
                    <Link to="/register" className="font-medium text-brand-accent hover:text-sky-300">
                        Register here
                    </Link>
                </p>
            </div>
        </div>
    );
};

export default LoginPage;
