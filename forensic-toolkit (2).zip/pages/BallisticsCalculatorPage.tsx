
import React, { useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ArrowLeftIcon, CalculatorIcon, LightBulbIcon, ChevronDownIcon, ChevronUpIcon } from '@heroicons/react/24/outline';

import { BallisticsInputs, BallisticsResults, Tool, Environment } from '../types';
import { calculateBallistics, firearms } from '../services/forensicService';
import { getGeminiExplanation } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import Modal from '../components/Modal';

const defaultEnvironment: Environment = {
  temperatureC: 15,
  pressureHpa: 1013,
  humidity: 0.5,
  altitudeM: 0,
  windSpeed: 0,
  windAngleDeg: 90,
};

const defaultInputs: BallisticsInputs = {
  firearmId: firearms[2].id, // Default to AK-47
  targetDistance: 100,
  sightHeight: 0.05, // 5cm
  environment: defaultEnvironment,
};


const BallisticsCalculatorPage: React.FC = () => {
    const [inputs, setInputs] = useState<BallisticsInputs>(defaultInputs);
    const [results, setResults] = useState<BallisticsResults | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [modalContent, setModalContent] = useState('');
    const [isAiLoading, setIsAiLoading] = useState(false);
    const [envVisible, setEnvVisible] = useState(false);
    
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        const valueAsNumber = name !== 'firearmId' ? parseFloat(value) : value;

        if (Object.keys(defaultEnvironment).includes(name)) {
            setInputs(prev => ({
                ...prev,
                environment: {
                    ...prev.environment,
                    [name]: valueAsNumber
                }
            }));
        } else {
            setInputs(prev => ({ ...prev, [name]: valueAsNumber }));
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setResults(null);
        
        if (inputs.targetDistance <= 0) {
            setError("Target distance must be greater than zero.");
            return;
        }

        setIsLoading(true);
        try {
            const data = await calculateBallistics(inputs);
            setResults(data);
        } catch (err: any) {
            setError(err.message || 'Failed to calculate ballistics.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const fetchAiExplanation = useCallback(async () => {
        if (!results) return;
        setIsAiLoading(true);
        setModalContent('');
        try {
            const explanation = await getGeminiExplanation({
                toolName: Tool.Ballistics,
                inputs,
                results,
            });
            setModalContent(explanation);
            setIsModalOpen(true);
        } catch (err) {
            setModalContent('Failed to fetch AI explanation.');
            setIsModalOpen(true);
            console.error(err);
        } finally {
            setIsAiLoading(false);
        }
    }, [inputs, results]);

    const finalPoint = results?.trajectory[results.trajectory.length - 1];

    return (
        <div className="bg-slate-800 p-6 sm:p-8 rounded-xl shadow-2xl border border-slate-700">
            <Link to="/dashboard" className="inline-flex items-center text-brand-accent hover:text-sky-300 mb-6 text-sm font-medium">
                <ArrowLeftIcon className="h-4 w-4 mr-1" />
                Back to Dashboard
            </Link>
            <h1 className="text-3xl font-bold mb-1 text-sky-400 flex items-center">
                <CalculatorIcon className="h-8 w-8 mr-3 text-brand-accent" />
                Ballistics Calculator
            </h1>
            <p className="text-slate-300 mb-8">Simulate projectile trajectory considering firearm, target, and environmental factors.</p>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Form Inputs Column */}
                <div className="lg:col-span-1">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        {/* Firearm & Target Section */}
                        <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-700">
                            <h3 className="text-lg font-semibold text-sky-400 mb-4 border-b border-slate-600 pb-2">Setup</h3>
                            <div className="space-y-4">
                                <div>
                                    <label htmlFor="firearmId" className="block text-sm font-medium text-slate-300 mb-1">Firearm</label>
                                    <select id="firearmId" name="firearmId" value={inputs.firearmId} onChange={handleInputChange} className="w-full p-2 bg-slate-700 border border-slate-600 rounded-md focus:ring-brand-accent focus:border-brand-accent text-slate-100">
                                        {firearms.map(f => <option key={f.id} value={f.id}>{f.name} ({f.caliber})</option>)}
                                    </select>
                                </div>
                                <InputSlider label="Target Distance (m)" name="targetDistance" value={inputs.targetDistance} onChange={handleInputChange} min={1} max={2000} step={1} />
                                <InputSlider label="Sight Height (cm)" name="sightHeight" value={inputs.sightHeight * 100} onChange={(e) => { e.target.value = (parseFloat(e.target.value)/100).toString(); handleInputChange(e); }} min={0} max={10} step={0.1} unit="cm" />
                            </div>
                        </div>

                        {/* Environment Section */}
                        <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-700">
                           <button type="button" onClick={() => setEnvVisible(!envVisible)} className="w-full flex justify-between items-center text-lg font-semibold text-sky-400 mb-2">
                               <span>Environmental Conditions</span>
                               {envVisible ? <ChevronUpIcon className="h-5 w-5"/> : <ChevronDownIcon className="h-5 w-5"/>}
                           </button>
                           {envVisible && (
                               <div className="space-y-4 pt-2 border-t border-slate-600">
                                    <InputSlider label="Temperature (°C)" name="temperatureC" value={inputs.environment.temperatureC} onChange={handleInputChange} min={-40} max={50} step={1} unit="°C" />
                                    <InputSlider label="Pressure (hPa)" name="pressureHpa" value={inputs.environment.pressureHpa} onChange={handleInputChange} min={800} max={1100} step={1} unit="hPa"/>
                                    <InputSlider label="Humidity (%)" name="humidity" value={inputs.environment.humidity * 100} onChange={(e) => { e.target.value = (parseFloat(e.target.value)/100).toString(); handleInputChange(e); }} min={0} max={100} step={1} unit="%"/>
                                    <InputSlider label="Altitude (m)" name="altitudeM" value={inputs.environment.altitudeM} onChange={handleInputChange} min={0} max={4000} step={10} unit="m"/>
                                    <InputSlider label="Wind Speed (m/s)" name="windSpeed" value={inputs.environment.windSpeed} onChange={handleInputChange} min={0} max={50} step={1} unit="m/s"/>
                                    <InputSlider label="Wind Angle (°)" name="windAngleDeg" value={inputs.environment.windAngleDeg} onChange={handleInputChange} min={0} max={360} step={1} unit="°"/>
                               </div>
                           )}
                        </div>
                        
                        <button type="submit" disabled={isLoading} className="w-full px-6 py-3 bg-brand-accent text-white font-semibold rounded-md hover:bg-sky-500 transition-colors disabled:opacity-50 flex items-center justify-center">
                            {isLoading ? <LoadingSpinner size="sm" /> : 'Calculate Trajectory'}
                        </button>
                        {error && <p className="text-red-400 bg-red-900/30 p-3 rounded-md text-sm">{error}</p>}
                    </form>
                </div>

                {/* Results Column */}
                <div className="lg:col-span-2">
                    {isLoading && <div className="h-full flex items-center justify-center"><LoadingSpinner text="Calculating..." /></div>}
                    {!isLoading && results && results.trajectory.length > 0 && (
                        <div className="space-y-6 animate-fadeIn">
                            <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-700">
                                <h3 className="text-xl font-semibold text-sky-300 mb-4">Results at Target ({finalPoint?.distance.toFixed(0)}m)</h3>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                                    <MetricDisplay label="Drop" value={`${(finalPoint?.drop ?? 0).toFixed(2)} m`} />
                                    <MetricDisplay label="Wind Drift" value={`${(finalPoint?.windDrift ?? 0).toFixed(2)} m`} />
                                    <MetricDisplay label="Velocity" value={`${(finalPoint?.velocity ?? 0).toFixed(0)} m/s`} />
                                    <MetricDisplay label="Energy" value={`${(finalPoint?.energy ?? 0).toFixed(0)} J`} />
                                </div>
                            </div>
                            <div className="p-4 bg-slate-700/50 rounded-lg border border-slate-700">
                                <h3 className="text-xl font-semibold text-sky-300 mb-4">Trajectory Plot</h3>
                                <ResponsiveContainer width="100%" height={300}>
                                    <LineChart data={results.trajectory} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                                        <XAxis dataKey="distance" unit="m" stroke="#94a3b8" tick={{ fontSize: 12 }} />
                                        <YAxis unit="m" stroke="#94a3b8" tick={{ fontSize: 12 }} domain={['auto', 'auto']} />
                                        <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', color: '#e2e8f0' }} labelStyle={{ color: '#94a3b8' }} formatter={(value: number) => value.toFixed(2)} />
                                        <Legend wrapperStyle={{fontSize: "12px"}}/>
                                        <Line type="monotone" dataKey="drop" name="Drop (m)" stroke="#38bdf8" strokeWidth={2} dot={false} />
                                        <Line type="monotone" dataKey="windDrift" name="Wind Drift (m)" stroke="#f472b6" strokeWidth={2} dot={false} />
                                    </LineChart>
                                </ResponsiveContainer>
                            </div>
                            <button onClick={fetchAiExplanation} disabled={isAiLoading} className="px-5 py-2 bg-sky-600 text-white font-medium rounded-md hover:bg-sky-700 transition-colors disabled:opacity-50 flex items-center">
                                <LightBulbIcon className="h-5 w-5 mr-2" />
                                {isAiLoading ? <LoadingSpinner size="sm" /> : 'Get AI Insights'}
                            </button>
                        </div>
                    )}
                    {!isLoading && !results && <div className="h-full flex items-center justify-center text-slate-500">Enter parameters and calculate to see results.</div>}
                </div>
            </div>
             <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="AI Forensic Explanation">
                {isAiLoading ? <LoadingSpinner text="Generating insights..." /> : <div dangerouslySetInnerHTML={{ __html: modalContent.replace(/\n/g, '<br />') }} />}
            </Modal>
        </div>
    );
};

const InputSlider: React.FC<{label: string, name: string, value: number, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, min: number, max: number, step: number, unit?: string}> = ({label, name, value, onChange, min, max, step, unit}) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-slate-300 mb-1 flex justify-between">
            <span>{label}</span>
            <span className="text-sky-400 font-mono">{value} {unit}</span>
        </label>
        <input type="range" id={name} name={name} value={value} onChange={onChange} min={min} max={max} step={step} className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-brand-accent"/>
    </div>
);

const MetricDisplay: React.FC<{ label: string, value: string }> = ({ label, value }) => (
    <div className="bg-slate-600 p-2 rounded-md">
        <p className="text-xs text-slate-400 uppercase">{label}</p>
        <p className="text-lg font-bold text-slate-100">{value}</p>
    </div>
);

export default BallisticsCalculatorPage;