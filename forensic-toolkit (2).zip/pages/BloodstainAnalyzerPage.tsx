
import React, { useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { BloodstainInputs, BloodstainResult, Tool } from '../types';
import { calculateBloodstainAngle } from '../services/forensicService';
import { getGeminiExplanation } from '../services/geminiService';
import Modal from '../components/Modal';
import LoadingSpinner from '../components/LoadingSpinner';
import { ArrowLeftIcon, LightBulbIcon, BeakerIcon } from '@heroicons/react/24/outline';
import BloodstainIcon from '../components/icons/BloodstainIcon'; // Themed Icon

const BloodstainAngleVisualizer: React.FC<{ angle: number, width: number, length: number }> = ({ angle, width, length }) => {
  if (isNaN(angle) || angle <= 0 || angle > 90 || width <=0 || length <=0 || width > length) {
    return <p className="text-slate-400 italic">Provide valid stain dimensions to visualize angle.</p>;
  }

  const ellipseHeight = 100; // px, visual height of ellipse for drawing
  const ellipseWidth = (width / length) * ellipseHeight / Math.sin(angle * Math.PI / 180) * Math.cos(angle * Math.PI / 180); // This needs review.
  // More simply, the visual representation of the stain width is width, and length is length
  // For visualization, let's represent the stain itself and the angle line.
  // An ellipse with rx related to length, ry related to width.
  // Max visual dimensions:
  const vizWidth = 200; // Max width for visualization container
  const scale = vizWidth / Math.max(length, 50); // Scale factor, ensure length is not too small
  const scaledLength = length * scale;
  const scaledWidth = width * scale;

  // Calculate the angle in radians for trigonometric functions
  const angleRad = angle * (Math.PI / 180);

  // Calculate the coordinates for the line representing the impact angle
  const lineLength = scaledLength * 0.8; // Make line proportional to stain length
  const lineEndX = lineLength * Math.cos(angleRad);
  const lineEndY = lineLength * Math.sin(angleRad);
  
  // Determine dimensions for the ellipse (bloodstain)
  // The ellipse's major axis is 'length', minor axis is 'width'
  const ellipseRx = scaledLength / 2;
  const ellipseRy = scaledWidth / 2;

  return (
    <div className="mt-4 p-4 bg-slate-600 rounded-md">
      <h4 className="text-lg font-medium text-sky-300 mb-2">Angle Visualization</h4>
      <svg width={vizWidth} height={vizWidth * 0.75} viewBox={`0 0 ${vizWidth} ${vizWidth * 0.75}`} className="bg-slate-500 rounded">
        {/* Origin reference */}
        <circle cx={10} cy={vizWidth * 0.75 - 10} r="2" fill="#63A4FF" />
        <text x={15} y={vizWidth * 0.75 - 5} fontSize="10" fill="#cbd5e1">Origin</text>

        {/* Impact surface (horizontal line) */}
        <line x1="0" y1={vizWidth * 0.75 - 10} x2={vizWidth} y2={vizWidth * 0.75 - 10} stroke="#94a3b8" strokeWidth="1" />
        <text x={vizWidth - 30} y={vizWidth * 0.75 - 15} fontSize="10" fill="#cbd5e1">Surface</text>
        
        {/* Elliptical stain shape centered around where line impacts */}
        {/* Position the ellipse at the end of the angle line */}
        <g transform={`translate(${10 + lineEndX}, ${vizWidth * 0.75 - 10 - lineEndY}) rotate(${-angle})`}>
            <ellipse 
                cx="0" 
                cy="0" 
                rx={ellipseRx} 
                ry={ellipseRy} 
                fill="rgba(239, 68, 68, 0.7)" /* Red with opacity */
                stroke="#dc2626"
                strokeWidth="1"
            />
        </g>

        {/* Angle line */}
        <line 
          x1={10} // Start from origin
          y1={vizWidth * 0.75 - 10} 
          x2={10 + lineEndX} 
          y2={vizWidth * 0.75 - 10 - lineEndY} 
          stroke="#63A4FF" 
          strokeWidth="2" 
        />
        
        {/* Angle arc */}
        <path 
          d={`M ${10 + 30} ${vizWidth * 0.75 - 10} A 30 30 0 0 1 ${10 + 30 * Math.cos(angleRad)} ${vizWidth * 0.75 - 10 - 30 * Math.sin(angleRad)}`} 
          fill="none" 
          stroke="#a7f3d0" 
          strokeWidth="1" 
        />
        <text x={10 + 35 * Math.cos(angleRad/2)} y={vizWidth * 0.75 - 10 - 35 * Math.sin(angleRad/2)} fontSize="10" fill="#a7f3d0" dominantBaseline="middle" textAnchor="middle">
          {angle.toFixed(1)}°
        </text>
      </svg>
    </div>
  );
};


const BloodstainAnalyzerPage: React.FC = () => {
  const [inputs, setInputs] = useState<BloodstainInputs>({ stainWidth: 5, stainLength: 10 });
  const [results, setResults] = useState<BloodstainResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputs({ ...inputs, [e.target.name]: parseFloat(e.target.value) });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setResults(null);
     if (isNaN(inputs.stainWidth) || isNaN(inputs.stainLength) || inputs.stainWidth <= 0 || inputs.stainLength <= 0) {
      setError('Please enter valid positive numbers for stain width and length.');
      return;
    }
    if (inputs.stainWidth > inputs.stainLength) {
      setError('Stain width cannot be greater than stain length.');
      return;
    }
    setIsLoading(true);
    try {
      const data = await calculateBloodstainAngle(inputs);
      setResults(data);
    } catch (err) {
      setError('Failed to calculate bloodstain angle. Please try again.');
      console.error(err);
    }
    setIsLoading(false);
  };

  const fetchAiExplanation = useCallback(async () => {
    if (!results) return;
    setIsAiLoading(true);
    setModalContent('');
    try {
      const explanation = await getGeminiExplanation({
        toolName: Tool.Bloodstain,
        inputs,
        results,
      });
      setModalContent(explanation);
      setIsModalOpen(true);
    } catch (err) {
      setModalContent('Failed to fetch AI explanation.');
      setIsModalOpen(true);
      console.error(err);
    }
    setIsAiLoading(false);
  }, [inputs, results]);

  return (
    <div className="bg-slate-800 p-6 sm:p-8 rounded-xl shadow-2xl border border-slate-700">
      <Link to="/dashboard" className="inline-flex items-center text-brand-accent hover:text-sky-300 mb-6 text-sm font-medium">
        <ArrowLeftIcon className="h-4 w-4 mr-1" />
        Back to Dashboard
      </Link>
      <h1 className="text-3xl font-bold mb-1 text-sky-400 flex items-center">
        <BloodstainIcon className="h-8 w-8 mr-3 text-brand-accent" />
        Bloodstain Pattern Analyzer
      </h1>
      <p className="text-slate-300 mb-8">Calculate the angle of impact of a bloodstain based on its width and length.</p>

      <form onSubmit={handleSubmit} className="space-y-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="stainWidth" className="block text-sm font-medium text-slate-300 mb-1">Stain Width (mm)</label>
            <input
              type="number"
              name="stainWidth"
              id="stainWidth"
              value={inputs.stainWidth}
              onChange={handleInputChange}
              min="0.1"
              step="0.1"
              required
              className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md focus:ring-brand-accent focus:border-brand-accent text-slate-100 placeholder-slate-400"
              placeholder="e.g., 5"
            />
          </div>
          <div>
            <label htmlFor="stainLength" className="block text-sm font-medium text-slate-300 mb-1">Stain Length (mm)</label>
            <input
              type="number"
              name="stainLength"
              id="stainLength"
              value={inputs.stainLength}
              onChange={handleInputChange}
              min="0.1"
              step="0.1"
              required
              className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md focus:ring-brand-accent focus:border-brand-accent text-slate-100 placeholder-slate-400"
              placeholder="e.g., 10"
            />
          </div>
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="w-full md:w-auto px-6 py-3 bg-brand-accent text-white font-semibold rounded-md hover:bg-sky-500 transition-colors disabled:opacity-50 flex items-center justify-center"
        >
          {isLoading ? <LoadingSpinner size="sm" /> : <><BeakerIcon className="h-5 w-5 mr-2" /> Calculate Impact Angle</>}
        </button>
      </form>

      {error && <p className="text-red-400 bg-red-900/30 p-3 rounded-md text-sm mb-6">{error}</p>}

      {isLoading && <div className="my-6"><LoadingSpinner text="Calculating angle..." /></div>}

      {results && !isLoading && (
        <div className="mt-8 p-6 bg-slate-700 rounded-lg shadow animate-fadeIn">
          <h2 className="text-2xl font-semibold text-sky-300 mb-4">Analysis Results</h2>
          <div className="bg-slate-600 p-4 rounded-md shadow inline-block">
            <p className="text-sm text-slate-400">Impact Angle</p>
            <p className="text-3xl font-bold text-slate-100">{results.impactAngle.toFixed(2)}°</p>
          </div>
          
          <BloodstainAngleVisualizer angle={results.impactAngle} width={inputs.stainWidth} length={inputs.stainLength} />

          <button
            onClick={fetchAiExplanation}
            disabled={isAiLoading}
            className="mt-6 px-5 py-2 bg-sky-600 text-white font-medium rounded-md hover:bg-sky-700 transition-colors disabled:opacity-50 flex items-center"
          >
            <LightBulbIcon className="h-5 w-5 mr-2" />
            {isAiLoading ? <LoadingSpinner size="sm" text="Analyzing..." /> : 'Get AI Insights'}
          </button>
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="AI Forensic Explanation">
        {isAiLoading ? <LoadingSpinner text="Generating insights..." /> : <div dangerouslySetInnerHTML={{ __html: modalContent.replace(/\n/g, '<br />') }} />}
      </Modal>
    </div>
  );
};

export default BloodstainAnalyzerPage;