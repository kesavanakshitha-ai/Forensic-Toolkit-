
import React, { useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { BlockchainEvidenceInput, BlockchainStoreResult, Tool } from '../types';
import { storeEvidenceOnBlockchain } from '../services/forensicService';
import { getGeminiExplanation } from '../services/geminiService';
import Modal from '../components/Modal';
import LoadingSpinner from '../components/LoadingSpinner';
import { ArrowLeftIcon, LightBulbIcon, DocumentPlusIcon, ShieldCheckIcon } from '@heroicons/react/24/outline';
import BlockchainIcon from '../components/icons/BlockchainIcon'; // Themed Icon

const BlockchainEvidencePage: React.FC = () => {
  const [inputs, setInputs] = useState<BlockchainEvidenceInput>({ caseId: '', evidenceHash: '', evidenceDescription: '' });
  const [results, setResults] = useState<BlockchainStoreResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setResults(null);
    if (!inputs.caseId.trim() || !inputs.evidenceHash.trim() || !inputs.evidenceDescription.trim()) {
      setError('All fields are required.');
      return;
    }
    if (!/^[a-fA-F0-9]{64}$/.test(inputs.evidenceHash)) {
       setError('Evidence Hash must be a 64-character hexadecimal string (e.g., SHA-256).');
       return;
    }

    setIsLoading(true);
    try {
      const data = await storeEvidenceOnBlockchain(inputs);
      setResults(data);
    } catch (err) {
      setError('Failed to store evidence on blockchain. Please try again.');
      console.error(err);
    }
    setIsLoading(false);
  };

  const fetchAiExplanation = useCallback(async () => {
    if (!results) return;
    setIsAiLoading(true);
    setModalContent('');
    try {
      const explanation = await getGeminiExplanation({
        toolName: Tool.Blockchain,
        inputs,
        results,
      });
      setModalContent(explanation);
      setIsModalOpen(true);
    } catch (err) {
      setModalContent('Failed to fetch AI explanation.');
      setIsModalOpen(true);
      console.error(err);
    }
    setIsAiLoading(false);
  }, [inputs, results]);

  return (
    <div className="bg-slate-800 p-6 sm:p-8 rounded-xl shadow-2xl border border-slate-700">
      <Link to="/dashboard" className="inline-flex items-center text-brand-accent hover:text-sky-300 mb-6 text-sm font-medium">
        <ArrowLeftIcon className="h-4 w-4 mr-1" />
        Back to Dashboard
      </Link>
      <h1 className="text-3xl font-bold mb-1 text-sky-400 flex items-center">
        <BlockchainIcon className="h-8 w-8 mr-3 text-brand-accent" />
        Blockchain Evidence Manager
      </h1>
      <p className="text-slate-300 mb-8">Securely log evidence details and hash onto a simulated immutable blockchain ledger.</p>

      <form onSubmit={handleSubmit} className="space-y-6 mb-8">
        <div>
          <label htmlFor="caseId" className="block text-sm font-medium text-slate-300 mb-1">Case ID</label>
          <input
            type="text"
            name="caseId"
            id="caseId"
            value={inputs.caseId}
            onChange={handleInputChange}
            required
            className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md focus:ring-brand-accent focus:border-brand-accent text-slate-100 placeholder-slate-400"
            placeholder="e.g., CASE-2024-001"
          />
        </div>
        <div>
          <label htmlFor="evidenceHash" className="block text-sm font-medium text-slate-300 mb-1">Evidence Hash (SHA-256)</label>
          <input
            type="text"
            name="evidenceHash"
            id="evidenceHash"
            value={inputs.evidenceHash}
            onChange={handleInputChange}
            required
            pattern="[a-fA-F0-9]{64}"
            title="Must be a 64-character hexadecimal string"
            className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md focus:ring-brand-accent focus:border-brand-accent text-slate-100 placeholder-slate-400"
            placeholder="64-character hexadecimal string"
          />
        </div>
         <div>
          <label htmlFor="evidenceDescription" className="block text-sm font-medium text-slate-300 mb-1">Evidence Description</label>
          <textarea
            name="evidenceDescription"
            id="evidenceDescription"
            value={inputs.evidenceDescription}
            onChange={handleInputChange}
            required
            rows={3}
            className="w-full p-3 bg-slate-700 border border-slate-600 rounded-md focus:ring-brand-accent focus:border-brand-accent text-slate-100 placeholder-slate-400"
            placeholder="Brief description of the evidence"
          />
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="w-full md:w-auto px-6 py-3 bg-brand-accent text-white font-semibold rounded-md hover:bg-sky-500 transition-colors disabled:opacity-50 flex items-center justify-center"
        >
          {isLoading ? <LoadingSpinner size="sm" /> : <><DocumentPlusIcon className="h-5 w-5 mr-2" /> Store Evidence</>}
        </button>
      </form>

      {error && <p className="text-red-400 bg-red-900/30 p-3 rounded-md text-sm mb-6">{error}</p>}

      {isLoading && <div className="my-6"><LoadingSpinner text="Storing evidence on blockchain..." /></div>}

      {results && !isLoading && (
        <div className="mt-8 p-6 bg-slate-700 rounded-lg shadow animate-fadeIn">
          <h2 className="text-2xl font-semibold text-sky-300 mb-4 flex items-center">
            <ShieldCheckIcon className="h-7 w-7 mr-2 text-green-400" />
            Evidence Stored Successfully
          </h2>
          <div className="space-y-3 text-slate-200">
            <p><strong className="text-slate-400">Case ID:</strong> {inputs.caseId}</p>
            <p><strong className="text-slate-400">Transaction Hash:</strong> <span className="break-all text-sm font-mono">{results.transactionHash}</span></p>
            <p><strong className="text-slate-400">Timestamp:</strong> {new Date(results.timestamp).toLocaleString()}</p>
            <p><strong className="text-slate-400">Simulated Block #:</strong> {results.blockNumber}</p>
            <p><strong className="text-slate-400">Original Hash Stored:</strong> <span className="break-all text-sm font-mono">{inputs.evidenceHash}</span></p>
          </div>
          
          <button
            onClick={fetchAiExplanation}
            disabled={isAiLoading}
            className="mt-6 px-5 py-2 bg-sky-600 text-white font-medium rounded-md hover:bg-sky-700 transition-colors disabled:opacity-50 flex items-center"
          >
            <LightBulbIcon className="h-5 w-5 mr-2" />
            {isAiLoading ? <LoadingSpinner size="sm" text="Analyzing..." /> : 'Get AI Insights'}
          </button>
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="AI Forensic Explanation">
         {isAiLoading ? <LoadingSpinner text="Generating insights..." /> : <div dangerouslySetInnerHTML={{ __html: modalContent.replace(/\n/g, '<br />') }} />}
      </Modal>
    </div>
  );
};

export default BlockchainEvidencePage;