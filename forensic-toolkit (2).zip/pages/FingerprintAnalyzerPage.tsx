
import React, { useState, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import { FingerprintAnalysisResult, Tool } from '../types';
import { analyzeFingerprint } from '../services/forensicService';
import { getGeminiExplanation } from '../services/geminiService';
import Modal from '../components/Modal';
import LoadingSpinner from '../components/LoadingSpinner';
import { ArrowLeftIcon, LightBulbIcon, CheckCircleIcon, XCircleIcon, PhotoIcon, CameraIcon } from '@heroicons/react/24/outline';
import FingerprintIcon from '../components/icons/FingerprintIcon';

const FingerprintAnalyzerPage: React.FC = () => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [processedImageUrl, setProcessedImageUrl] = useState<string | null>(null);
  const [results, setResults] = useState<FingerprintAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [analysisStep, setAnalysisStep] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);

  const handleImageChange = (file: File | null) => {
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setError('File size exceeds 5MB. Please choose a smaller image.');
        return;
      }
      setError(null);
      setResults(null);
      setProcessedImageUrl(null);
      const reader = new FileReader();
      reader.onload = (e) => setImageUrl(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraOpen(true);
    } catch (err) {
      console.error("Error accessing camera:", err);
      setError("Could not access camera. Please ensure permissions are granted.");
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setIsCameraOpen(false);
  };
  
  const takePicture = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      canvas.getContext('2d')?.drawImage(videoRef.current, 0, 0);
      canvas.toBlob(blob => {
        if(blob) {
            handleImageChange(new File([blob], "fingerprint.png", { type: "image/png" }));
        }
      }, 'image/png');
      stopCamera();
    }
  };

  const runAnalysisSimulation = async () => {
    if (!imageUrl) return;

    setIsLoading(true);
    setResults(null);
    setProcessedImageUrl(null);
    setError(null);

    try {
        const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d', { willReadFrequently: true });
        if (!ctx) throw new Error("Could not get canvas context");

        const img = new Image();
        img.crossOrigin = "Anonymous";
        await new Promise<void>((resolve, reject) => {
            img.onload = () => resolve();
            img.onerror = reject;
            img.src = imageUrl;
        });
        
        const MAX_WIDTH = 512;
        const scale = Math.min(1, MAX_WIDTH / img.width);
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        setAnalysisStep("Step 1/4: Enhancing ridges...");
        await delay(600);
        let imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        let data = imageData.data;
        const contrast = 128;
        const factor = (259 * (contrast + 255)) / (255 * (259 - contrast));
        for (let i = 0; i < data.length; i += 4) {
            const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
            const gray = factor * (avg - 128) + 128;
            data[i] = data[i + 1] = data[i + 2] = gray;
        }
        ctx.putImageData(imageData, 0, 0);

        setAnalysisStep("Step 2/4: Skeletonizing print...");
        await delay(600);
        const threshold = 100;
        for (let i = 0; i < data.length; i += 4) {
            const color = data[i] < threshold ? 0 : 255;
            data[i] = data[i + 1] = data[i + 2] = color;
        }
        ctx.putImageData(imageData, 0, 0);

        setAnalysisStep("Step 3/4: Extracting minutiae...");
        await delay(800);
        let minutiaeCount = 0;
        const isRidge = (x: number, y: number) => {
            if (x < 0 || x >= canvas.width || y < 0 || y >= canvas.height) return 0;
            return data[(y * canvas.width + x) * 4] < threshold ? 1 : 0;
        };

        const minutiaePoints: {x: number, y: number, type: 'ending' | 'bifurcation'}[] = [];
        const step = 5;
        for (let y = step; y < canvas.height - step; y += step) {
            for (let x = step; x < canvas.width - step; x += step) {
                if (isRidge(x, y)) {
                    let neighbors = 0;
                    for(let j = -1; j <= 1; j++) {
                        for(let i = -1; i <= 1; i++) {
                            if (i === 0 && j === 0) continue;
                            if (isRidge(x + i, y + j)) neighbors++;
                        }
                    }
                    if (neighbors === 1) minutiaePoints.push({x, y, type: 'ending'});
                    else if (neighbors === 3) minutiaePoints.push({x, y, type: 'bifurcation'});
                }
            }
        }
        
        minutiaePoints.forEach(p => {
             minutiaeCount++;
             ctx.beginPath();
             ctx.arc(p.x, p.y, Math.max(2, canvas.width / 150), 0, 2 * Math.PI);
             ctx.fillStyle = p.type === 'ending' ? 'rgba(56, 189, 248, 0.8)' : 'rgba(74, 222, 128, 0.8)'; // Sky blue for endings, green for bifurcations
             ctx.strokeStyle = '#000';
             ctx.lineWidth = 0.5;
             ctx.fill();
             ctx.stroke();
        });


      setAnalysisStep("Step 4/4: Finalizing results...");
      await delay(500);
      setProcessedImageUrl(canvas.toDataURL());
      const backendResults = await analyzeFingerprint();
      setResults({ ...backendResults, minutiaePoints: minutiaeCount });

    } catch (err: any) {
      setError(`An error occurred during analysis: ${err.message || 'Unknown error'}`);
      console.error(err);
    } finally {
      setIsLoading(false);
      setAnalysisStep('');
    }
  };

  const fetchAiExplanation = useCallback(async () => {
    if (!results) return;
    setIsAiLoading(true);
    setModalContent('');
    try {
      const explanation = await getGeminiExplanation({
        toolName: Tool.Fingerprint,
        inputs: { imageProvided: true, analysisMethod: 'Simulated Ridge Skeletonization & Minutiae Extraction' },
        results,
      });
      setModalContent(explanation);
      setIsModalOpen(true);
    } catch (err) {
      setModalContent('Failed to fetch AI explanation.');
      setIsModalOpen(true);
      console.error(err);
    }
    setIsAiLoading(false);
  }, [results]);
  
  const reset = () => {
    setImageUrl(null);
    setProcessedImageUrl(null);
    setResults(null);
    setError(null);
    if(isCameraOpen) stopCamera();
  }

  return (
    <div className="bg-slate-800 p-6 sm:p-8 rounded-xl shadow-2xl border border-slate-700">
      <Link to="/dashboard" className="inline-flex items-center text-brand-accent hover:text-sky-300 mb-6 text-sm font-medium">
        <ArrowLeftIcon className="h-4 w-4 mr-1" />
        Back to Dashboard
      </Link>
      <h1 className="text-3xl font-bold mb-1 text-sky-400 flex items-center">
        <FingerprintIcon className="h-8 w-8 mr-3 text-brand-accent" />
        Fingerprint Analyzer
      </h1>
      <p className="text-slate-300 mb-8">Upload or capture a fingerprint image to simulate a forensic analysis.</p>

      {error && <p className="text-red-400 bg-red-900/30 p-3 rounded-md text-sm mb-6">{error}</p>}
      
      {isCameraOpen && (
        <div className="mb-4">
          <video ref={videoRef} autoPlay playsInline className="w-full rounded-md border-2 border-brand-accent"></video>
          <div className="flex justify-center mt-4 gap-4">
            <button onClick={takePicture} className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Take Picture</button>
            <button onClick={stopCamera} className="px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">Cancel</button>
          </div>
        </div>
      )}

      {!imageUrl && !isCameraOpen && (
        <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-600 rounded-lg p-12 text-center">
          <PhotoIcon className="h-12 w-12 text-slate-500 mb-2" />
          <p className="text-slate-400 mb-4">Drag & drop an image or select a file</p>
          <div className="flex gap-4">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-5 py-2 bg-brand-accent text-white font-medium rounded-md hover:bg-sky-500 transition-colors"
            >
              Upload Image
            </button>
             <button
              onClick={startCamera}
              className="px-5 py-2 bg-slate-600 text-white font-medium rounded-md hover:bg-slate-500 transition-colors flex items-center"
            >
              <CameraIcon className="h-5 w-5 mr-2" /> Use Camera
            </button>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleImageChange(e.target.files ? e.target.files[0] : null)}
          />
        </div>
      )}

      {imageUrl && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="text-lg font-semibold text-sky-300 mb-2">Original Image</h3>
              <img src={imageUrl} alt="Original Fingerprint" className="rounded-lg shadow-md w-full aspect-square object-cover" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-sky-300 mb-2">Processed Image</h3>
              <div className="rounded-lg shadow-md w-full aspect-square bg-slate-700 flex items-center justify-center">
                {processedImageUrl ? (
                   <img src={processedImageUrl} alt="Processed Fingerprint" className="rounded-lg w-full aspect-square object-cover" />
                ) : (
                  isLoading ? <LoadingSpinner text={analysisStep} /> : <div className="text-slate-500">Awaiting analysis...</div>
                )}
              </div>
            </div>
          </div>
          
           <div className="flex flex-wrap gap-4 items-center">
            <button
              onClick={runAnalysisSimulation}
              disabled={isLoading || !!results}
              className="px-6 py-3 bg-brand-accent text-white font-semibold rounded-md hover:bg-sky-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? 'Analyzing...' : (results ? 'Analysis Complete' : 'Run Analysis')}
            </button>
             <button
              onClick={reset}
              className="px-4 py-2 bg-slate-600 text-slate-300 font-medium rounded-md hover:bg-slate-500 transition-colors"
            >
              Start Over
            </button>
          </div>
        </div>
      )}
      
      {results && !isLoading && (
        <div className="mt-8 p-6 bg-slate-700 rounded-lg shadow animate-fadeIn">
          <h2 className="text-2xl font-semibold text-sky-300 mb-4">Analysis Results</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 text-slate-200">
            <div className={`p-4 rounded-md shadow ${results.matchConfidence > 85 ? 'bg-green-700/50' : results.matchConfidence > 60 ? 'bg-yellow-700/50' : 'bg-red-700/50'}`}>
              <p className="text-sm text-slate-300">Match Confidence</p>
              <p className="text-2xl font-bold">{results.matchConfidence}%</p>
            </div>
            <div className={`p-4 rounded-md shadow flex items-center ${results.nistVerified ? 'bg-green-700/50' : 'bg-red-700/50'}`}>
              {results.nistVerified ? <CheckCircleIcon className="h-8 w-8 mr-2 text-green-300"/> : <XCircleIcon className="h-8 w-8 mr-2 text-red-300"/>}
              <div>
                <p className="text-sm text-slate-300">NIST Verified</p>
                <p className="text-xl font-bold">{results.nistVerified ? 'Verified' : 'Not Verified'}</p>
              </div>
            </div>
             <div className="bg-slate-600 p-4 rounded-md shadow">
              <p className="text-sm text-slate-400">Detected Minutiae Points</p> 
              <p className="text-xl font-bold">{results.minutiaePoints || 'N/A'}</p>
            </div>
          </div>
          
          <button
            onClick={fetchAiExplanation}
            disabled={isAiLoading}
            className="mt-4 px-5 py-2 bg-sky-600 text-white font-medium rounded-md hover:bg-sky-700 transition-colors disabled:opacity-50 flex items-center"
          >
            <LightBulbIcon className="h-5 w-5 mr-2" />
            {isAiLoading ? <LoadingSpinner size="sm" text="Analyzing..." /> : 'Get AI Insights'}
          </button>
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="AI Forensic Explanation">
         {isAiLoading ? <LoadingSpinner text="Generating insights..." /> : <div dangerouslySetInnerHTML={{ __html: modalContent.replace(/\n/g, '<br />') }} />}
      </Modal>
    </div>
  );
};

export default FingerprintAnalyzerPage;