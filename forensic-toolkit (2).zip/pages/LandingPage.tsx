import React from 'react';
import { Link, Navigate } from 'react-router-dom';
import LandingLogo from '../components/LandingLogo';
import { useAuth } from '../context/AuthContext';

const LandingPage: React.FC = () => {
    const { user } = useAuth();

    if (user) {
        return <Navigate to="/dashboard" replace />;
    }

    return (
        <div className="min-h-screen bg-brand-dark flex flex-col items-center justify-center text-center p-4">
            <LandingLogo />
            <h1 className="text-5xl font-bold text-brand-light mt-8 animate-fade-in-up" style={{ animationDelay: '1.2s' }}>
                Forensic Toolkit
            </h1>
            <p className="text-xl text-brand-accent mt-2 mb-12 animate-fade-in-up" style={{ animationDelay: '1.4s' }}>
                Your complete digital forensic analysis suite.
            </p>
            <div className="flex gap-4 animate-fade-in-up" style={{ animationDelay: '1.6s' }}>
                <Link to="/login" className="px-8 py-3 bg-brand-accent text-white font-semibold rounded-md hover:bg-sky-500 transition-colors text-lg">
                    Login
                </Link>
                <Link to="/register" className="px-8 py-3 bg-slate-700 text-brand-light font-semibold rounded-md hover:bg-slate-600 transition-colors text-lg">
                    Register
                </Link>
            </div>
        </div>
    );
};

export default LandingPage;