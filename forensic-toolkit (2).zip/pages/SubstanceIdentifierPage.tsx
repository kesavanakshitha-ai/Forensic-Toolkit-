
import React, { useState, useCallback, useRef } from 'react';
import { Link } from 'react-router-dom';
import { SubstanceAnalysisResult, Tool } from '../types';
import { identifySubstance } from '../services/forensicService';
import { getGeminiExplanation } from '../services/geminiService';
import Modal from '../components/Modal';
import LoadingSpinner from '../components/LoadingSpinner';
import { ArrowLeftIcon, LightBulbIcon, CheckCircleIcon, PhotoIcon, CameraIcon, BeakerIcon } from '@heroicons/react/24/outline';
import SubstanceIcon from '../components/icons/SubstanceIcon';

const SubstanceIdentifierPage: React.FC = () => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [results, setResults] = useState<SubstanceAnalysisResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);

  const handleImageChange = (file: File | null) => {
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        setError('File size exceeds 5MB. Please choose a smaller image.');
        return;
      }
      setError(null);
      setResults(null);
      const reader = new FileReader();
      reader.onload = (e) => setImageUrl(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setIsCameraOpen(true);
    } catch (err) {
      console.error("Error accessing camera:", err);
      setError("Could not access camera. Please ensure permissions are granted.");
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setIsCameraOpen(false);
  };
  
  const takePicture = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      canvas.getContext('2d')?.drawImage(videoRef.current, 0, 0);
      canvas.toBlob(blob => {
        if(blob) {
            handleImageChange(new File([blob], "substance.png", { type: "image/png" }));
        }
      }, 'image/png');
      stopCamera();
    }
  };

  const runAnalysis = async () => {
    if (!imageUrl) return;
    setIsLoading(true);
    setResults(null);
    setError(null);
    try {
      const analysisResult = await identifySubstance();
      setResults(analysisResult);
    } catch (err: any) {
      setError(`An error occurred during analysis: ${err.message || 'Unknown error'}`);
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchAiExplanation = useCallback(async () => {
    if (!results) return;
    setIsAiLoading(true);
    setModalContent('');
    try {
      const explanation = await getGeminiExplanation({
        toolName: Tool.Substance,
        inputs: { imageProvided: true, analysisMethod: 'Simulated Mass Spectrometry & Database Matching' },
        results,
      });
      setModalContent(explanation);
      setIsModalOpen(true);
    } catch (err) {
      setModalContent('Failed to fetch AI explanation.');
      setIsModalOpen(true);
      console.error(err);
    }
    setIsAiLoading(false);
  }, [results]);
  
  const reset = () => {
    setImageUrl(null);
    setResults(null);
    setError(null);
    if(isCameraOpen) stopCamera();
  }

  const categoryColor = results?.identifiedSubstance.category ? {
    'Stimulant': 'bg-yellow-500 text-yellow-900',
    'Narcotic': 'bg-blue-500 text-blue-900',
    'Depressant': 'bg-purple-500 text-purple-900',
    'Hallucinogen': 'bg-pink-500 text-pink-900',
    'Toxin': 'bg-red-500 text-red-900',
  }[results.identifiedSubstance.category] : 'bg-slate-500 text-slate-900';

  return (
    <div className="bg-slate-800 p-6 sm:p-8 rounded-xl shadow-2xl border border-slate-700">
      <Link to="/dashboard" className="inline-flex items-center text-brand-accent hover:text-sky-300 mb-6 text-sm font-medium">
        <ArrowLeftIcon className="h-4 w-4 mr-1" />
        Back to Dashboard
      </Link>
      <h1 className="text-3xl font-bold mb-1 text-sky-400 flex items-center">
        <SubstanceIcon className="h-8 w-8 mr-3 text-brand-accent" />
        Substance Identifier
      </h1>
      <p className="text-slate-300 mb-8">Upload or capture an image of a substance to run a simulated chemical analysis.</p>

      {error && <p className="text-red-400 bg-red-900/30 p-3 rounded-md text-sm mb-6">{error}</p>}
      
      {isCameraOpen && (
        <div className="mb-4">
          <video ref={videoRef} autoPlay playsInline className="w-full rounded-md border-2 border-brand-accent"></video>
          <div className="flex justify-center mt-4 gap-4">
            <button onClick={takePicture} className="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">Take Picture</button>
            <button onClick={stopCamera} className="px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700">Cancel</button>
          </div>
        </div>
      )}

      {!imageUrl && !isCameraOpen && (
        <div className="flex flex-col items-center justify-center border-2 border-dashed border-slate-600 rounded-lg p-12 text-center">
          <PhotoIcon className="h-12 w-12 text-slate-500 mb-2" />
          <p className="text-slate-400 mb-4">Drag & drop an image or select a file</p>
          <div className="flex gap-4">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-5 py-2 bg-brand-accent text-white font-medium rounded-md hover:bg-sky-500 transition-colors"
            >
              Upload Image
            </button>
             <button
              onClick={startCamera}
              className="px-5 py-2 bg-slate-600 text-white font-medium rounded-md hover:bg-slate-500 transition-colors flex items-center"
            >
              <CameraIcon className="h-5 w-5 mr-2" /> Use Camera
            </button>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleImageChange(e.target.files ? e.target.files[0] : null)}
          />
        </div>
      )}

      {imageUrl && (
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-sky-300 mb-2">Evidence Image</h3>
            <img src={imageUrl} alt="Substance evidence" className="rounded-lg shadow-md max-h-80 w-auto mx-auto" />
          </div>
          
           <div className="flex flex-wrap gap-4 items-center justify-center">
            <button
              onClick={runAnalysis}
              disabled={isLoading || !!results}
              className="px-6 py-3 bg-brand-accent text-white font-semibold rounded-md hover:bg-sky-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
            >
              <BeakerIcon className="h-5 w-5 mr-2"/>
              {isLoading ? 'Analyzing...' : (results ? 'Analysis Complete' : 'Analyze Substance')}
            </button>
             <button
              onClick={reset}
              className="px-4 py-2 bg-slate-600 text-slate-300 font-medium rounded-md hover:bg-slate-500 transition-colors"
            >
              Start Over
            </button>
          </div>
        </div>
      )}

      {isLoading && <div className="my-6"><LoadingSpinner text="Performing mass spectrometry..." /></div>}
      
      {results && !isLoading && (
        <div className="mt-8 p-6 bg-slate-700/70 rounded-lg shadow-inner border border-slate-700 animate-fadeIn">
          <h2 className="text-2xl font-semibold text-sky-300 mb-4 flex items-center">
            <CheckCircleIcon className="h-7 w-7 mr-2 text-green-400" />
            Analysis Results
          </h2>
          <div className="mb-6 bg-slate-900/50 p-4 rounded-lg">
            <p className="text-sm text-slate-400">Match Confidence</p>
            <p className="text-3xl font-bold text-green-300">{results.matchConfidence}%</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 text-slate-200">
              <div className="md:col-span-2">
                <h3 className="text-2xl font-bold text-white">{results.identifiedSubstance.name}</h3>
                <span className={`inline-block px-3 py-1 text-sm font-semibold rounded-full ${categoryColor} mt-1`}>
                    {results.identifiedSubstance.category}
                </span>
              </div>
              <InfoItem label="Chemical Name" value={results.identifiedSubstance.chemicalName} />
              <InfoItem label="Formula" value={results.identifiedSubstance.formula} />
              <InfoItem label="Legal Status" value={results.identifiedSubstance.legalStatus} />
              <InfoItem label="Lethal Dose" value={results.identifiedSubstance.lethalDose || 'N/A'} />
              <div className="md:col-span-2">
                 <InfoItem label="Common Effects" value={results.identifiedSubstance.effects} />
              </div>
               <div className="md:col-span-2">
                 <InfoItem label="Detection Methods" value={results.identifiedSubstance.detectionMethods} />
              </div>
          </div>
          
          <button
            onClick={fetchAiExplanation}
            disabled={isAiLoading}
            className="mt-6 px-5 py-2 bg-sky-600 text-white font-medium rounded-md hover:bg-sky-700 transition-colors disabled:opacity-50 flex items-center"
          >
            <LightBulbIcon className="h-5 w-5 mr-2" />
            {isAiLoading ? <LoadingSpinner size="sm" /> : 'Get AI Insights'}
          </button>
        </div>
      )}

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="AI Forensic Explanation">
         {isAiLoading ? <LoadingSpinner text="Generating insights..." /> : <div dangerouslySetInnerHTML={{ __html: modalContent.replace(/\n/g, '<br />') }} />}
      </Modal>
    </div>
  );
};

const InfoItem: React.FC<{label: string, value: string}> = ({label, value}) => (
    <div>
        <p className="text-sm font-semibold text-slate-400">{label}</p>
        <p className="text-base text-slate-100">{value}</p>
    </div>
);


export default SubstanceIdentifierPage;