
import React from 'react';

const BallisticsIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12.75 3.75v16.5M7.5 12.75h9M19.5 12.75l-7.5 7.5-7.5-7.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75c0-1.104.896-2 2-2h12.5c1.104 0 2 .896 2 2v10.5c0 1.104-.896 2-2 2H5.75c-1.104 0-2-.896-2-2V6.75z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6.75L12 10.5l-3.75-3.75" />
  </svg>
);

export default BallisticsIcon;
