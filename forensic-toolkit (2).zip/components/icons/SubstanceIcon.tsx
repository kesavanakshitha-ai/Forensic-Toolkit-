
import React from 'react';

const SubstanceIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.25 10.75c-.224 1.458-.932 2.754-1.92 3.752M9.75 10.75c.224 1.458.932 2.754 1.92 3.752m0 0l1.414 1.414M12 15.164l-1.414 1.414m2.828-2.828l1.414-1.414M12 15.164L10.586 13.75m2.828 2.828L13.414 13.75m-1.414-1.414L12 10.92m0 0L10.586 9.5m1.414 1.414L13.414 9.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 21v-4.875c0-.621.504-1.125 1.125-1.125h5.25c.621 0 1.125.504 1.125 1.125V21" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18h12" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18H4.5a2.25 2.25 0 01-2.25-2.25V6.75A2.25 2.25 0 014.5 4.5h15A2.25 2.25 0 0121.75 6.75v8.502c0 .54-.214 1.055-.595 1.434l-1.605 1.605" />
  </svg>
);

export default SubstanceIcon;
