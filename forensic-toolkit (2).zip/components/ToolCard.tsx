
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRightIcon } from '@heroicons/react/20/solid';

interface ToolCardProps {
  title: string;
  description: string;
  linkTo: string;
  icon: React.ReactNode;
}

const ToolCard: React.FC<ToolCardProps> = ({ title, description, linkTo, icon }) => {
  return (
    <Link 
      to={linkTo} 
      className="block bg-slate-800 hover:bg-slate-700 p-6 rounded-lg shadow-xl transition-all duration-300 ease-in-out transform hover:scale-105 border border-slate-700 hover:border-brand-accent"
    >
      <div className="flex items-center mb-4">
        <div className="p-3 rounded-full bg-brand-accent text-white mr-4">
          {icon}
        </div>
        <h3 className="text-xl font-semibold text-sky-400">{title}</h3>
      </div>
      <p className="text-slate-300 text-sm mb-4">{description}</p>
      <div className="flex justify-end items-center text-sm font-medium text-brand-accent hover:text-sky-300">
        Open Tool <ArrowRightIcon className="h-4 w-4 ml-1" />
      </div>
    </Link>
  );
};

export default ToolCard;
