import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { HomeIcon, ArrowRightOnRectangleIcon } from '@heroicons/react/24/solid';
import Logo from './Logo';
import { useAuth } from '../context/AuthContext';

const Header: React.FC = () => {
  const { user, logout } = useAuth();

  return (
    <header className="bg-brand-primary shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-1 flex justify-between items-center">
        <Link to="/dashboard" className="text-2xl font-bold text-brand-light transition-colors flex items-center">
          <Logo />
           <span className="ml-[-0.5rem] hidden sm:inline">Forensic Toolkit</span>
        </Link>
        <nav className="flex items-center space-x-4">
          <NavLink 
            to="/dashboard" 
            className={({ isActive }) => 
                `flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive ? 'text-sky-300 bg-brand-dark' : 'text-brand-light hover:text-brand-accent'
                }`
            }
          >
            <HomeIcon className="h-5 w-5 mr-1" /> Dashboard
          </NavLink>
          {user && (
            <button
              onClick={logout}
              className="flex items-center text-brand-light hover:text-brand-accent transition-colors px-3 py-2 rounded-md text-sm font-medium"
              aria-label="Logout"
            >
              <ArrowRightOnRectangleIcon className="h-5 w-5 mr-1" />
              Logout
            </button>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;