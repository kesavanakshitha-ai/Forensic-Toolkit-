import React from 'react';
import { BeakerIcon } from '@heroicons/react/24/solid';
import BallisticsIcon from './icons/BallisticsIcon';
import FingerprintIcon from './icons/FingerprintIcon';
import BlockchainIcon from './icons/BlockchainIcon';
import BloodstainIcon from './icons/BloodstainIcon';
import CrimeSceneIcon from './icons/CrimeSceneIcon';
import CameraIcon from './icons/CameraIcon';
import SubstanceIcon from './icons/SubstanceIcon';

const LandingLogo: React.FC = () => {
  const icons = [
    { component: <BallisticsIcon className="h-8 w-8 text-slate-300" />, name: 'Ballistics Calculator' },
    { component: <FingerprintIcon className="h-8 w-8 text-slate-300" />, name: 'Fingerprint Analyzer' },
    { component: <BlockchainIcon className="h-8 w-8 text-slate-300" />, name: 'Evidence Manager' },
    { component: <BloodstainIcon className="h-8 w-8" />, name: 'Bloodstain Analyzer' },
    { component: <CrimeSceneIcon className="h-8 w-8 text-slate-300" />, name: 'Crime Scene Search' },
    { component: <CameraIcon className="h-8 w-8 text-slate-300" />, name: 'Camera Input' },
    { component: <SubstanceIcon className="h-8 w-8 text-slate-300" />, name: 'Substance Analyzer' },
  ];
  const numIcons = icons.length;
  const radius = 90; // Larger radius for landing page

  return (
    <div className="relative w-52 h-52 flex items-center justify-center">
      <BeakerIcon className="h-20 w-20 text-brand-accent animate-center-pop-in" style={{ animationDelay: '0s' }} />
      {icons.map((icon, i) => {
        const angle = (i / numIcons) * 2 * Math.PI - (Math.PI / 2); 
        const x = radius * Math.cos(angle);
        const y = radius * Math.sin(angle);
        
        return (
          <div
            key={i}
            className="absolute animate-fly-from-center"
            // FIX: Cast style object to React.CSSProperties to allow for CSS custom properties.
            style={{
              left: '50%',
              top: '50%',
              '--final-translate-x': `calc(-50% + ${x}px)`,
              '--final-translate-y': `calc(-50% + ${y}px)`,
              animationDelay: `${0.2 + i * 0.1}s`,
            } as React.CSSProperties}
            title={icon.name}
          >
            {icon.component}
          </div>
        );
      })}
    </div>
  );
};

export default LandingLogo;