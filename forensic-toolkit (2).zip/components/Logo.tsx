import React from 'react';
import { BeakerIcon } from '@heroicons/react/24/solid';
import BallisticsIcon from './icons/BallisticsIcon';
import FingerprintIcon from './icons/FingerprintIcon';
import BlockchainIcon from './icons/BlockchainIcon';
import BloodstainIcon from './icons/BloodstainIcon';
import CrimeSceneIcon from './icons/CrimeSceneIcon';
import CameraIcon from './icons/CameraIcon';
import SubstanceIcon from './icons/SubstanceIcon';

const Logo: React.FC = () => {
  const icons = [
    { component: <BallisticsIcon className="h-5 w-5 text-slate-300 group-hover:text-sky-300 transition-colors" />, name: 'Ballistics Calculator' },
    { component: <FingerprintIcon className="h-5 w-5 text-slate-300 group-hover:text-sky-300 transition-colors" />, name: 'Fingerprint Analyzer' },
    { component: <BlockchainIcon className="h-5 w-5 text-slate-300 group-hover:text-sky-300 transition-colors" />, name: 'Evidence Manager' },
    { component: <BloodstainIcon className="h-5 w-5" />, name: 'Bloodstain Analyzer' },
    { component: <CrimeSceneIcon className="h-5 w-5 text-slate-300 group-hover:text-sky-300 transition-colors" />, name: 'Crime Scene Search' },
    { component: <CameraIcon className="h-5 w-5 text-slate-300 group-hover:text-sky-300 transition-colors" />, name: 'Camera Input' },
    { component: <SubstanceIcon className="h-5 w-5 text-slate-300 group-hover:text-sky-300 transition-colors" />, name: 'Substance Analyzer' },
  ];
  const numIcons = icons.length;
  const radius = 38; // in pixels

  return (
    <div className="relative w-24 h-24 flex items-center justify-center group">
      <BeakerIcon className="h-10 w-10 text-brand-accent group-hover:text-sky-300 transition-colors" />
      {icons.map((icon, i) => {
        // Start from the top and distribute icons evenly
        const angle = (i / numIcons) * 2 * Math.PI - (Math.PI / 2); 
        const x = radius * Math.cos(angle);
        const y = radius * Math.sin(angle);
        
        return (
          <div
            key={i}
            className="absolute transition-transform duration-300 group-hover:scale-125"
            style={{
              left: `calc(50% + ${x}px)`,
              top: `calc(50% + ${y}px)`,
              transform: 'translate(-50%, -50%)',
            }}
            title={icon.name}
          >
            {icon.component}
          </div>
        );
      })}
    </div>
  );
};

export default Logo;
