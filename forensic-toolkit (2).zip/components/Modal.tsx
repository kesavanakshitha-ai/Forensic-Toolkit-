
import React from 'react';
import { XMarkIcon } from '@heroicons/react/24/outline';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-slate-800 p-6 rounded-lg shadow-xl max-w-2xl w-full max-h-[80vh] flex flex-col border border-slate-700">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-sky-400">{title}</h3>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-sky-400 transition-colors"
            aria-label="Close modal"
          >
            <XMarkIcon className="h-6 w-6" />
          </button>
        </div>
        <div className="overflow-y-auto flex-grow prose prose-invert max-w-none prose-sm sm:prose-base">
          {children}
        </div>
         <div className="mt-6 text-right">
            <button
              onClick={onClose}
              className="px-4 py-2 bg-brand-accent text-white rounded-md hover:bg-sky-500 transition-colors text-sm font-medium"
            >
              Close
            </button>
          </div>
      </div>
    </div>
  );
};

export default Modal;
