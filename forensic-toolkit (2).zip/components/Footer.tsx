import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-primary text-brand-light text-center p-4 mt-auto">
      <p>&copy; {new Date().getFullYear()} Forensic Toolkit. All rights reserved.</p>
      <p className="text-xs mt-1">Simulated tools for demonstration purposes.</p>
    </footer>
  );
};

export default Footer;